using System.ComponentModel.DataAnnotations; using System.ComponentModel.DataAnnotations.Schema;
namespace Lesson09bai1.Models;
[Table("Banner")]
public class Banner { public int Id {get;set;} [Required(ErrorMessage="Vui lòng nhập tên banner")] [StringLength(100)] [Display(Name="Tên banner")] public string Name {get;set;}=""; [Range(0,255)] [Display(Name="Trạng thái")] public byte Status {get;set;}=1; [Display(Name="Độ ưu tiên")] public int Priority {get;set;}=0; [StringLength(100)] public string? Image {get;set;} [StringLength(350)] public string? Description {get;set;} }
