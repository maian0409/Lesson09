using System.ComponentModel.DataAnnotations; using System.ComponentModel.DataAnnotations.Schema;
namespace Lesson09bai1.Models;
[Table("Blog")]
public class Blog { public int Id {get;set;} [Required(ErrorMessage="Vui lòng nhập tiêu đề bài viết")] [StringLength(100)] [Display(Name="Tiêu đề")] public string Name {get;set;}=""; [Range(0,255)] [Display(Name="Trạng thái")] public byte Status {get;set;}=1; [DataType(DataType.Date)] [Display(Name="Ngày tạo")] public DateTime CreatedDate {get;set;}=DateTime.Today; [StringLength(100)] public string? Image {get;set;} [StringLength(350)] public string? Description {get;set;} }
