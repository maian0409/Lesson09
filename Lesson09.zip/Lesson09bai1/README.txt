LESSON09 - TONG HOP BAI 1 VA BAI 2

Bai 1: Giao dien quan tri AdminLTE 3, dashboard, layout va cac partial view Header, NavLeft, Footer.
Bai 2: ASP.NET Core MVC + Entity Framework Core CRUD cho Category, Product, Banner va Blog. Product co khoa ngoai CategoryId. Co validation va xac nhan xoa.

Yeu cau: .NET 6 SDK, SQL Server LocalDB (hoac sua connection string trong appsettings.json).

Cach chay:
1. Giai nen file ZIP.
2. Mo Lesson09bai1/Lesson09bai1.csproj bang Visual Studio.
3. Restore NuGet packages.
4. Mo Tools > NuGet Package Manager > Package Manager Console, chon project Lesson09bai1 va chay:
   Add-Migration InitialCreate
   Update-Database
5. Nhan F5.

Trang quan tri: /Admin/Home/Index
CRUD: /Admin/Category, /Admin/Product, /Admin/Banner, /Admin/Blog
