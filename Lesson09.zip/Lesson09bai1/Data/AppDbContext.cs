using Lesson09bai1.Models;
using Microsoft.EntityFrameworkCore;
namespace Lesson09bai1.Data;
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Banner> Banners => Set<Banner>();
    public DbSet<Blog> Blogs => Set<Blog>();
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>().HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Product>().HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Banner>().HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Blog>().HasIndex(x => x.Name).IsUnique();
        modelBuilder.Entity<Category>().Property(x => x.Status).HasDefaultValue((byte)1);
        modelBuilder.Entity<Category>().Property(x => x.CreatedDate).HasDefaultValueSql("CONVERT(date, GETDATE())");
        modelBuilder.Entity<Product>().Property(x => x.SalePrice).HasDefaultValue(0f);
        modelBuilder.Entity<Product>().Property(x => x.Status).HasDefaultValue((byte)1);
        modelBuilder.Entity<Product>().Property(x => x.CreatedDate).HasDefaultValueSql("CONVERT(date, GETDATE())");
        modelBuilder.Entity<Banner>().Property(x => x.Status).HasDefaultValue((byte)1);
        modelBuilder.Entity<Banner>().Property(x => x.Priority).HasDefaultValue(0);
        modelBuilder.Entity<Blog>().Property(x => x.Status).HasDefaultValue((byte)1);
        modelBuilder.Entity<Blog>().Property(x => x.CreatedDate).HasDefaultValueSql("CONVERT(date, GETDATE())");
        modelBuilder.Entity<Product>().HasOne(x => x.Category).WithMany(x => x.Products).HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
    }
}
