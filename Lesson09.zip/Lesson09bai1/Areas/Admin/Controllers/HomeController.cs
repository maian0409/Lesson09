using Microsoft.AspNetCore.Mvc;
namespace lap08.Areas.Admin.Controllers;
[Area("Admin")]
public class HomeController : Controller
{
    public IActionResult Index() => View();
}
