using Lesson09bai1.Data;
using Lesson09bai1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace Lesson09bai1.Areas.Admin.Controllers;
[Area("Admin")]
public class CategoryController : Controller
{
    private readonly AppDbContext _context;
    public CategoryController(AppDbContext context) { _context = context; }
    public async Task<IActionResult> Index() { return View(await _context.Categories.ToListAsync()); }
    public async Task<IActionResult> Details(int? id) { if (id == null) return NotFound(); var item = await _context.Categories.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    public IActionResult Create() { return View(new Category()); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Category item)
    {
        if (await _context.Categories.AnyAsync(x => x.Name == item.Name)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { _context.Add(item); await _context.SaveChangesAsync(); TempData["Success"] = "Thêm danh mục thành công."; return RedirectToAction(nameof(Index)); }
        return View(item);
    }
    public async Task<IActionResult> Edit(int? id) { if (id == null) return NotFound(); var item = await _context.Categories.FindAsync(id); if (item == null) return NotFound(); return View(item); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Category item)
    {
        if (id != item.Id) return NotFound();
        if (await _context.Categories.AnyAsync(x => x.Name == item.Name && x.Id != item.Id)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { try { _context.Update(item); await _context.SaveChangesAsync(); TempData["Success"] = "Cập nhật thành công."; } catch (DbUpdateConcurrencyException) { if (!await _context.Categories.AnyAsync(x => x.Id == item.Id)) return NotFound(); else throw; } return RedirectToAction(nameof(Index)); }
        return View(item);
    }
    public async Task<IActionResult> Delete(int? id) { if (id == null) return NotFound(); var item = await _context.Categories.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    [HttpPost, ActionName("Delete")] [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await _context.Categories.FindAsync(id); if (item != null) {
            if (await _context.Products.AnyAsync(p => p.CategoryId == id)) { TempData["Error"] = "Không thể xóa danh mục đang được sản phẩm sử dụng."; return RedirectToAction(nameof(Index)); }
            _context.Categories.Remove(item); await _context.SaveChangesAsync(); TempData["Success"] = "Xóa thành công."; }
        return RedirectToAction(nameof(Index));
    }
}
