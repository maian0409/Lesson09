using Lesson09bai1.Data;
using Lesson09bai1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
namespace Lesson09bai1.Areas.Admin.Controllers;
[Area("Admin")]
public class ProductController : Controller
{
    private readonly AppDbContext _context;
    public ProductController(AppDbContext context) { _context = context; }
    private async Task LoadCategories() { ViewBag.CategoryId = new SelectList(await _context.Categories.OrderBy(c => c.Name).ToListAsync(), "Id", "Name"); }
    public async Task<IActionResult> Index() { return View(await _context.Products.Include(p => p.Category).ToListAsync()); }
    public async Task<IActionResult> Details(int? id) { if (id == null) return NotFound(); var item = await _context.Products.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    public async Task<IActionResult> Create() { await LoadCategories(); return View(new Product()); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Product item)
    {
        if (await _context.Products.AnyAsync(x => x.Name == item.Name)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { _context.Add(item); await _context.SaveChangesAsync(); TempData["Success"] = "Thêm sản phẩm thành công."; return RedirectToAction(nameof(Index)); }
        await LoadCategories(); return View(item);
    }
    public async Task<IActionResult> Edit(int? id) { if (id == null) return NotFound(); var item = await _context.Products.FindAsync(id); if (item == null) return NotFound(); await LoadCategories(); return View(item); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Product item)
    {
        if (id != item.Id) return NotFound();
        if (await _context.Products.AnyAsync(x => x.Name == item.Name && x.Id != item.Id)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { try { _context.Update(item); await _context.SaveChangesAsync(); TempData["Success"] = "Cập nhật thành công."; } catch (DbUpdateConcurrencyException) { if (!await _context.Products.AnyAsync(x => x.Id == item.Id)) return NotFound(); else throw; } return RedirectToAction(nameof(Index)); }
        await LoadCategories(); return View(item);
    }
    public async Task<IActionResult> Delete(int? id) { if (id == null) return NotFound(); var item = await _context.Products.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    [HttpPost, ActionName("Delete")] [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await _context.Products.FindAsync(id); if (item != null) {
            _context.Products.Remove(item); await _context.SaveChangesAsync(); TempData["Success"] = "Xóa thành công."; }
        return RedirectToAction(nameof(Index));
    }
}
