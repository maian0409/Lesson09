using Lesson09bai1.Data;
using Lesson09bai1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace Lesson09bai1.Areas.Admin.Controllers;
[Area("Admin")]
public class BannerController : Controller
{
    private readonly AppDbContext _context;
    public BannerController(AppDbContext context) { _context = context; }
    public async Task<IActionResult> Index() { return View(await _context.Banners.ToListAsync()); }
    public async Task<IActionResult> Details(int? id) { if (id == null) return NotFound(); var item = await _context.Banners.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    public IActionResult Create() { return View(new Banner()); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Banner item)
    {
        if (await _context.Banners.AnyAsync(x => x.Name == item.Name)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { _context.Add(item); await _context.SaveChangesAsync(); TempData["Success"] = "Thêm banner thành công."; return RedirectToAction(nameof(Index)); }
        return View(item);
    }
    public async Task<IActionResult> Edit(int? id) { if (id == null) return NotFound(); var item = await _context.Banners.FindAsync(id); if (item == null) return NotFound(); return View(item); }
    [HttpPost] [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Banner item)
    {
        if (id != item.Id) return NotFound();
        if (await _context.Banners.AnyAsync(x => x.Name == item.Name && x.Id != item.Id)) ModelState.AddModelError(nameof(item.Name), "Tên đã tồn tại.");
        if (ModelState.IsValid) { try { _context.Update(item); await _context.SaveChangesAsync(); TempData["Success"] = "Cập nhật thành công."; } catch (DbUpdateConcurrencyException) { if (!await _context.Banners.AnyAsync(x => x.Id == item.Id)) return NotFound(); else throw; } return RedirectToAction(nameof(Index)); }
        return View(item);
    }
    public async Task<IActionResult> Delete(int? id) { if (id == null) return NotFound(); var item = await _context.Banners.FirstOrDefaultAsync(x => x.Id == id); if (item == null) return NotFound(); return View(item); }
    [HttpPost, ActionName("Delete")] [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await _context.Banners.FindAsync(id); if (item != null) {
            _context.Banners.Remove(item); await _context.SaveChangesAsync(); TempData["Success"] = "Xóa thành công."; }
        return RedirectToAction(nameof(Index));
    }
}
