using Microsoft.AspNetCore.Mvc;
namespace lap08.Controllers;
public class HomeController : Controller
{
    public IActionResult Index() => RedirectToAction("Index", "Home", new { area = "Admin" });
}
